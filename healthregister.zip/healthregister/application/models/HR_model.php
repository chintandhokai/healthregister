<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class HR_model extends CI_Model
{
    public function islogin()
    {
        if(!($this->session->userdata('accno'))){
            $this->HR_model->err('<strong>Ops !</strong> Look\'s like you havn\'t Login yet. <br> Please Login.');
            redirect('/', 'refresh');
            die();
        }
    }
    public function err($message)
    {
        $this->session->set_flashdata('alert','danger');
        $this->session->set_flashdata('message',$message);
    }
    public function noerr($message)
    {
        $this->session->set_flashdata('alert','success');
        $this->session->set_flashdata('message',$message);
    }
    public function enc($n)
    {
        $key = "HR";
        $iv ="B9F128D827203729";
        $encrypted = bin2hex(openssl_encrypt($n,'AES-128-CBC', $key,0,$iv));
        return $encrypted;
    }
    public function dec($n)
    {
        $key = "HR";
        $iv ="B9F128D827203729";
        $decrypted=openssl_decrypt(hex2bin($n),'AES-128-CBC',$key,0,$iv);
        return $decrypted;
    }
}
