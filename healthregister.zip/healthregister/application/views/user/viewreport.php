<?php
echo $this->session->userdata('id');
$query = $this->db->get_where('hr_report',array('hru_user_ID'=>$this->session->userdata('id')));
                foreach ($query->result() as $row){
                    echo $row->hrr_report_type;
                    
                    $query1 = $this->db->get_where('hr_user',array('hru_ID'=>$row->hru_doctor_ID));
                    $row1 = $query1->row();
                    if($query1->num_rows() == 1){
                        echo $row1->hru_name;
                        }  
                    $query1 = $this->db->get_where('hr_user',array('hru_ID'=>$row->hru_chemist_ID));
                    $row1 = $query1->row();
                    if($query1->num_rows() == 1){
                        echo $row1->hru_name;
                        }
                }
?>
