<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor and book online an appointment">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main>
        <div class="bg_color_2">
            <div class="container margin_60_35">
                <div id="register">
                    <h1>Register</h1>
                    <div class="row justify-content-center">
                        <div class="col-md-5">
                            <form method="post" action="/register/userprocess" enctype="multipart/form-data" data-parsley-validate novalidates>
                                <div class="box_form">
                                    <div class="row">
                                        <div class="col-md-12 ">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Name" name="name_register" id="name_register" data-parsley-required-message="Name is required." required>
                                            </div>
                                        </div>

                                    </div>

                                    <!-- /row -->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="City" name="city_register" id="city_register" data-parsley-required-message="City is required." required>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- /row -->
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Address" name="address_register" id="address_register" data-parsley-required-message="Address is required." required>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /row -->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Mobile Phone" name="mobile_register" id="mobile_register" data-parsley-required-message="Mobile No is required." required>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- /row -->
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input type="email" class="form-control" placeholder="Email Address" name="email_register" id="email_register" data-parsley-trigger="keyup" class="form-control" placeholder="Enter your email" data-parsley-remote-options='{ "type": "POST" }' data-parsley-remote-validator="validateEmail" data-parsley-remote-message="Email already exists." data-parsley-required-message="Email is required." data-parsley-type-message="Email must be valid." data-parsley-remote data-parsley-required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input type="password" class="form-control" placeholder="Password" name="password_register" id="password_register" data-parsley-required-message="Password is required." required>
                                            </div>
                                        </div>
                                    </div>
                                    <div><input type="submit" class="btn_1" value="Submit" id="submit-register"></div>
                                </div>

                            </form>
                        </div>
                    </div>
                    <!-- /row -->
                </div>
                <!-- /register -->
            </div>
        </div>
    </main>
    <!-- /main -->
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
?>
    <script>
        Parsley.addAsyncValidator('validateEmail', function(xhr) {
            console.clear();
            return 404 === xhr.status;
        }, '/welcome/register_email_exists/');

    </script>
</body>

</html>
