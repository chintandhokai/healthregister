<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$query = $this->db->query("SELECT * FROM `hr_user` WHERE `hru_bloodgroup` LIKE '%".$keyword."%' OR `hru_city` LIKE '%".$keyword."%'");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main class="theia-exception">
        <div id="results">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h4><strong>Showing </strong>results for <?php echo $keyword; ?></h4>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /results -->


        <div class="container margin_60_35">
            <div class="row">
                <?php
                foreach ($query->result() as $row){
                ?>
                <div class="col-md-6">
                    <div class="strip_list wow fadeIn">

                        <figure>
                            <a href="#"><img src="data:image/png;base64,<?php echo base64_encode($row->hru_avtar)?>" alt=""></a>
                        </figure>
                        <?php
                    
                    ?>
                        <h2><?php echo $row->hru_name; ?></h2>
                        <p>Blood-group: <b><?php echo $row->hru_bloodgroup; ?></b></p>
                        <p>Mobile No.: <b><?php echo $row->hru_mobile; ?></b></p>
                        <p><?php echo $row->hru_address; ?>, <?php echo $row->hru_city; ?></p>

                    </div>
                </div>
                <!-- /col -->
                <?php
                }
                ?>

                <!-- /aside -->

            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </main>
    <!-- /main -->
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
?>

</body>

</html>
