<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$query = $this->db->where('hru_role','doctor');
$query = $this->db->get('hr_user');
$query1 = $this->db->where('hru_role','chemist');
$query1 = $this->db->get('hr_user');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main>
        <div class="hero_home version_1">
            <div class="content">
                <h3>Health Register</h3>
                <p>
                    Find easily a doctor with Health Register
                </p>
                <form id="myForm" action="/search">
                    <div id="custom-search-input">
                        <div class="input-group" id="the-search">
                            <input onkeyup="searchsend(this.value);" type="text" class="search-query typeahead" placeholder="Ex. Name, Specialization ....">
                            <input type="submit" target="_blank" class="btn_search" value="Search">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /Hero -->
        <div class="bg_color_1">
            <div class="container margin_120_95">

                <div class="main_title">
                    <h2>List of Doctors</h2>
                    <p>Find easily a doctor with Health Register</p>
                </div>

                <div id="reccomended" class="owl-carousel owl-theme">
                    <?php
                foreach ($query->result() as $row){
                ?>
                    <div class="item">
                        <a href="detail-page.html">

                            <div class="title">
                                <h4>Dr. <?php echo ucwords($row->hru_name); ?><em><?php echo $row->hru_specialization; ?></em></h4>
                            </div><img src="/assets/img/doctor.jpg" alt="">
                        </a>
                    </div>
                    <?php
                }?>
                </div>
            </div>
        </div>
        <!-- /carousel -->
        <div class="bg_color_1">
            <div class="container margin_120_95">

                <div class="main_title">
                    <h2>List of Clinic</h2>
                    <p>Find easily a Clinic with Health Register</p>
                </div>

                <div id="reccomended" class="owl-carousel owl-theme">
                    <?php
                foreach ($query1->result() as $row){
                ?>
                    <div class="item">
                        <a href="detail-page.html">

                            <div class="title">
                                <h4><?php echo ucwords($row->hru_clinic); ?><br><small><?php echo ucwords($row->hru_name); ?></small><em><?php echo $row->hru_city; ?></em></h4>
                            </div><img src="/assets/img/chemist.jpg" alt="">
                        </a>
                    </div>
                    <?php
                }?>
                </div>
            </div>
        </div>
    </main>
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
    $query2 = $this->db->distinct();
    $query2 = $this->db->select('hru_name');
    $query2 = $this->db->get('hr_user'); 
    $query3 = $this->db->distinct();
    $query3 = $this->db->select('hru_specialization');
    $query3 = $this->db->get('hr_user');
    $query4 = $this->db->distinct();
    $query4 = $this->db->select('hru_city');
    $query4 = $this->db->get('hr_user');
?>

    <script src="/assets/js/typeahead.bundle.js"></script>
    <script>
        var substringMatcher = function(strs) {
            return function findMatches(q, cb) {
                var matches, substringRegex;

                // an array that will be populated with substring matches
                matches = [];

                // regex used to determine if a string contains the substring `q`
                substrRegex = new RegExp(q, 'i');

                // iterate through the pool of strings and for any string that
                // contains the substring `q`, add it to the `matches` array
                $.each(strs, function(i, str) {
                    if (substrRegex.test(str)) {
                        matches.push(str);
                    }
                });

                cb(matches);
            };
        };

        var category = [
            <?php
            foreach ($query2->result() as $row){
                echo '\''.$row->hru_name.'\',';
            } 
            foreach ($query3->result() as $row){
                echo '\''.$row->hru_specialization.'\',';
            }
            foreach ($query4->result() as $row){
                echo '\''.$row->hru_city.'\',';
            } 
            
            ?>
        ];

        $('#the-search .typeahead').typeahead({
            hint: true,
            highlight: true,
            minLength: 1
        }, {
            name: 'category',
            source: substringMatcher(category)
        });

        function searchsend(page) {
            document.getElementById("myForm").action = "/search/result/" + page;
        }

    </script>

</body>

</html>
