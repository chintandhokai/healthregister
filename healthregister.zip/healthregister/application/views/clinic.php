<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$query = $this->db->where('hru_role','chemist');
$query = $this->db->get('hr_user');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main class="theia-exception">
        <div id="results">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h4><strong>Showing </strong>results</h4>
                    </div>
                    <div class="col-md-6">
                        <div class="search_bar_list">
                            <input type="text" class="form-control" placeholder="Ex. Specialist, Name, Doctor...">
                            <input type="submit" value="Search">
                        </div>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /results -->


        <div class="container margin_60_35">
            <div class="row">
                <?php
                foreach ($query->result() as $row){
                ?>
                <div class="col-md-6">
                    <div class="strip_list wow fadeIn">
                       
                        <figure>
                            <a href="#"><img src="data:image/png;base64,<?php echo base64_encode($row->hru_avtar)?>" alt=""></a>
                        </figure>

                        <h3><?php echo $row->hru_clinic; ?></h3>
                        <p><b><?php echo $row->hru_specialization; ?></b></p>
                        <p><?php echo $row->hru_address; ?>, <?php echo $row->hru_city; ?></p>
                      
                    </div>
                </div>
                <!-- /col -->
                <?php
                }
                ?>

                <!-- /aside -->

            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </main>
    <!-- /main -->
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
?>

</body>

</html>
