<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor and book online an appointment">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main>
        <div class="bg_color_2">
            <div class="container margin_60_35">
                <div id="login">
                    <h1>Login </h1>
                    <div class="box_form">
                        <form method="post" action="/login/loginprocess" data-parsley-validate novalidates>
                            <!-------------------------------Alert Start---------------------------------->
                            <?php $this->load->view('/parts/alert'); ?>
                            <!-------------------------------Alert End---------------------------------->
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Your email address" name="email" id="email" data-parsley-required-message="Email is required." required>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Your password" id="password" name="password" data-parsley-required-message="Password is required." required>
                            </div>
                            <a href="#0"><small>Forgot password?</small></a>
                            <div class="form-group text-center add_top_20">
                                <input class="btn_1 medium" type="submit" value="Login">
                            </div>
                        </form>
                    </div>
                    <p class="text-center link_bright">Do not have an account yet? <a href="/register"><strong>Register now!</strong></a></p>
                </div>
                <!-- /login -->
            </div>
        </div>
    </main>
    <!-- /main -->
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
?>

</body>

</html>
