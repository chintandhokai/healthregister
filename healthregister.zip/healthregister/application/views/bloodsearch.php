<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$query = $this->db->where('hru_role','user');
$query = $this->db->get('hr_user');
$query1 = $this->db->where('hru_role','user');
$query1 = $this->db->get('hr_user');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main>
        <div class="hero_home version_1">
            <div class="content">
                <h3>Health Register</h3>
                <p>
                    Find easily a Blood with Health Register
                </p>
                <form id="myForm" action="/search">
                    <div id="custom-search-input">
                        <div class="input-group" id="the-search">
                            <input onkeyup="searchsend(this.value);" type="text" class="search-query typeahead" placeholder="Ex. Blood group..">
                            <input type="submit" target="_blank" class="btn_search" value="Search">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /Hero -->
        <!-- /carousel -->
        
    </main>
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
    $query = $this->db->distinct();
    $query = $this->db->select('hru_bloodgroup');
    $query = $this->db->get('hr_user'); 
    $query1 = $this->db->distinct();
    $query1 = $this->db->select('hru_city');
    $query1 = $this->db->get('hr_user');
   
?>

    <script src="/assets/js/typeahead.bundle.js"></script>
    <script>
        var substringMatcher = function(strs) {
            return function findMatches(q, cb) {
                var matches, substringRegex;

                // an array that will be populated with substring matches
                matches = [];

                // regex used to determine if a string contains the substring `q`
                substrRegex = new RegExp(q, 'i');

                // iterate through the pool of strings and for any string that
                // contains the substring `q`, add it to the `matches` array
                $.each(strs, function(i, str) {
                    if (substrRegex.test(str)) {
                        matches.push(str);
                    }
                });

                cb(matches);
            };
        };

        var category = [
            <?php
            foreach ($query->result() as $row){
                echo '\''.$row->hru_bloodgroup.'\',';
            } 
            foreach ($query1->result() as $row){
                echo '\''.$row->hru_city.'\',';
            }
           
            ?>
        ];

        $('#the-search .typeahead').typeahead({
            hint: true,
            highlight: true,
            minLength: 1
        }, {
            name: 'category',
            source: substringMatcher(category)
        });

        function searchsend(page) {
            document.getElementById("myForm").action = "/search/bloodresult/" + page;
        }

    </script>

</body>

</html>
