<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor and book online an appointment">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main>
        <div id="hero_register">
            <div class="container margin_120_95">
                <div class="row">
                    <div class="col-lg-6">
                        <h1>It's time to find you!</h1>
                        <p class="lead">Find easily a doctor and book online an appointment</p>
                        <div class="box_feat_2">
                            <i class="pe-7s-map-2"></i>
                            <h3>Let patients to Find you!</h3>
                            <p>Ut nam graece accumsan cotidieque. Has voluptua vivendum accusamus cu. Ut per assueverit temporibus dissentiet.</p>
                        </div>
                        <div class="box_feat_2">
                            <i class="pe-7s-date"></i>
                            <h3>Easly manage Bookings</h3>
                            <p>Has voluptua vivendum accusamus cu. Ut per assueverit temporibus dissentiet. Eum no atqui putant democritum, velit nusquam sententiae vis no.</p>
                        </div>
                        <div class="box_feat_2">
                            <i class="pe-7s-phone"></i>
                            <h3>Instantly via Mobile</h3>
                            <p>Eos eu epicuri eleifend suavitate, te primis placerat suavitate his. Nam ut dico intellegat reprehendunt, everti audiam diceret in pri, id has clita consequat suscipiantur.</p>
                        </div>
                    </div>
                    <!-- /col -->
                    <div class="col-lg-5 ml-auto">
                        <div class="box_form">
                            <div id="message-register"></div>
                            <form method="post" action="/register/doctorprocess" enctype="multipart/form-data" data-parsley-validate novalidates>
                                <div class="row">
                                    <div class="col-md-12 ">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Name" name="name_register" id="name_register" data-parsley-required-message="Name is required." required>
                                        </div>
                                    </div>

                                </div>
                                <!-- /row -->
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Specialization" name="specialization" id="specialization" data-parsley-required-message="Specialization  is required." required>
                                        </div>
                                    </div>
                                </div>
                                <!-- /row -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="City" name="city_register" id="city_register" data-parsley-required-message="City is required." required>
                                        </div>
                                    </div>

                                </div>
                                <!-- /row -->
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Address" name="address_register" id="address_register" data-parsley-required-message="Address is required." required>
                                        </div>
                                    </div>
                                </div>
                                <!-- /row -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Mobile Phone" name="mobile_register" id="mobile_register" data-parsley-required-message="Mobile no is required." required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Office Phone" name="office_phone_register" id="office_phone_register" data-parsley-required-message="Office mobile no is required." required>
                                        </div>
                                    </div>
                                </div>
                                <!-- /row -->
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <input type="email" class="form-control" placeholder="Email Address" name="email_register" id="email_register" data-parsley-trigger="keyup" class="form-control" placeholder="Enter your email" data-parsley-remote-options='{ "type": "POST" }' data-parsley-remote-validator="validateEmail" data-parsley-remote-message="Email already exists." data-parsley-required-message="Email is required." data-parsley-type-message="Email must be valid." data-parsley-remote data-parsley-required>
                                        </div>
                                    </div>
                                </div>
                                <!-- /row -->
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <input type="password" class="form-control" placeholder="Password" name="password_register" id="password_register" data-parsley-required-message="Password is required." required>
                                        </div>
                                    </div>
                                </div>
                                <div><input type="submit" class="btn_1" value="Submit" id="submit-register"></div>
                            </form>
                        </div>
                        <!-- /box_form -->
                    </div>
                    <!-- /col -->
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /hero_register -->
    </main>
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
?>
    <script>
        Parsley.addAsyncValidator('validateEmail', function(xhr) {
            console.clear();
            return 404 === xhr.status;
        }, '/welcome/register_email_exists/');

    </script>

</body>

</html>
