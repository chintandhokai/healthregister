<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Health Regiter - Find easily a doctor</title>
    <meta name="description" content="Find easily a doctor and book online an appointment">
    <?php
$this->load->view('/parts/headermeta');
?>
</head>

<body>

    <?php
	$this->load->view('/parts/header');
	?>
    <main>
        <div class="bg_color_2">
            <div class="container margin_60_35">
                <div id="login">
                    <h1>Register as</h1>
                    <div class="box_form">
                        <form method="get" action="/register/user">
                            <div class="form-group text-center add_top_20">
                                <input class="btn_1 medium" type="submit" value="User">
                            </div>
                        </form>
                        <form method="get" action="/register/doctor">
                            <div class="form-group text-center add_top_20">
                                <input class="btn_1 medium" type="submit" value="Doctor">
                            </div>
                        </form>
                        <form method="get" action="/register/doctor">
                            <div class="form-group text-center add_top_20">
                                <input class="btn_1 medium" type="submit" value="Chemist">
                            </div>
                        </form>
                    </div>

                </div>
                <!-- /login -->
            </div>
        </div>
    </main>
    <!-- /main -->
    <?php
$this->load->view('/parts/footer');
?>
    <?php
$this->load->view('/parts/footermeta');
?>

</body>

</html>
