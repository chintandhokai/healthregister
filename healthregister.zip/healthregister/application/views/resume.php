<?php
$query = $this->db->get_where('hr_user',array('hru_ID'=>$id));
$row = $query->row();
?>
<iframe width="100%" height="97%" src="data:application/pdf;base64,<?php echo base64_encode($row->hru_resume); ?>"></iframe>
