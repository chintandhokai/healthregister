<?php
$query = $this->db->get_where('hr_user',array('hru_email'=>$this->session->userdata('email')));
$row = $query->row();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
	$this->load->view('/parts/pheadermeta');
	?>
</head>

<body class="fixed-nav sticky-footer" id="page-top">
    <!-- Navigation-->
    <?php
	$this->load->view('/doctor/navigation');
	?>
    <!-- /Navigation-->
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="/doctor/profile">View Profile</a>
                </li>
                <li class="breadcrumb-item active">Manage profile</li>
            </ol>
            <form enctype="multipart/form-data" action="/doctor/profileedit" method="post" data-parsley-validate novalidate>
                <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="box_general padding_bottom">
                            <div class="header_box version_2">
                                <h2><i class="fa fa-user"></i>Profile details</h2>
                            </div>
                            <br>
                            <?php
                                if($row->hru_avtar == ''){
                                ?>
                            <div class="image-upload text-center">
                                <label for="file-input">
                                    <div class="img-text">
                                        <img src="/assets/img/view.png" alt="Avatar" class="img-fluid rounded-circle mb-3" width="100">
                                        <div class="middle">
                                            <div class="text">Upload Image</div>
                                        </div>
                                    </div>
                                </label>
                                <input id="file-input" name="avtar" type="file" />
                            </div>
                            <?php
                                }
                                else{
                                ?>
                            <div class="image-upload text-center">
                                <label for="file-input">
                                    <div class="img-text">
                                        <img src="data:image/png;base64,<?php echo base64_encode($row->hru_avtar)?>" alt="Avatar" class="img-fluid rounded-circle mb-3" width="100">
                                        <div class="middle">
                                            <div class="text">Upload Image</div>
                                        </div>

                                    </div>
                                </label>
                                <input id="file-input" name="avtar" type="file" />
                            </div>
                            <?php
                                }
                                ?>

                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" value="<?php echo $row->hru_name; ?>" name="name" placeholder="Your name">
                            </div>

                            <!-- /row-->
                            <div class="form-group">
                                <label>Specialization</label>
                                <input type="text" class="form-control" value="<?php echo $row->hru_specialization; ?>" name="specialization" placeholder="Your Specialization">
                            </div>

                            <div class="form-group">
                                <label>Mobile No.</label>
                                <input type="text" class="form-control" value="<?php echo $row->hru_mobile; ?>" name="mobile" placeholder="Your Mobile number">
                            </div>
                            <div class="form-group">
                                <label>Blood Group</label>
                                <input type="varchar" class="form-control" value="<?php echo $row->hru_bloodgroup; ?>" name="bloodgroup" placeholder="Your Blood Group">
                            </div>
                            <?php
                                if($row->hru_gender == 'M'){
                                    $m = 'checked';
                                    $f = '';
                                }
                                else if($row->hru_gender == 'F'){
                                    $f = 'checked';
                                    $m = '';
                                }else{
                                    $f=$m='';
                                }
                                ?>
                            <div class="form-group">
                                <label>Gender</label><br><input type="radio" id="genderM" name="gender" value="M" <?php echo $m; ?> data-parsley-required-message="Gender is required." data-parsley-required> <label for="genderM" checked="true"> &nbsp;&nbsp;Male</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="radio" id="genderF" name="gender" value="F" <?php echo $f; ?>><label for="genderF"> &nbsp;&nbsp;Female</label>
                            </div>

                            <div class="form-group">
                                <label for="dob">Date of Birth : </label>
                                <input id="dob" type="date" name="dob" class="form-control" data-parsley-required-message="Date of Birth is required." value="<?php echo $row->hru_dob; ?>" data-parsley-required>
                            </div>
                            <div class="form-group">
                                <label for="file-input1">Upload Resume</label>
                                <input class="form-control" name="resume" id="file-input1" type="file" />
                            </div>
                            <?php
                                if($row->hru_resume == ''){
                                ?>

                            <?php
                                }
                                else{
                                ?>

                            <div class="form-group">
                                <!--                                <a href="data:image/png;base64,<?php echo base64_encode($row->hru_resume)?>" class="form-control" target="_blank"><button type="button" class="btn btn-block">View Resume</button></a>-->
                                <a href="/doctor/resume/<?php echo $row->hru_ID; ?>" class="form-control" target="_blank"><button type="button" class="btn btn-block">View Resume</button></a>
                            </div>
                            <?php
                                }
                                    ?>

                            <div class="form-group">
                                <label>City</label>
                                <input type="text" class="form-control" value="<?php echo $row->hru_city; ?>" name="city" placeholder="Your name">
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <input type="text" class="form-control" value="<?php echo $row->hru_address; ?>" name="address" placeholder="Your name">
                            </div>

                            <!-- /row-->
                            <button type="submit" class="btn_1 medium">Update detail</button>
                        </div>
                    </div>

                </div>
            </form>
        </div>
        <!-- /box_general-->

    </div>
    <footer class="sticky-footer">
        <div class="container">
            <div class="text-center">
                <small>Copyright © Health Register 2019</small>
            </div>
        </div>
    </footer>
    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <?php
	$this->load->view('/logout');
	?>
    <!-- Bootstrap core JavaScript-->
    <?php
	$this->load->view('/parts/pfootermeta');
	?>


</body>

</html>
