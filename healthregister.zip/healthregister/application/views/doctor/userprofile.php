<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$query = $this->db->where('hru_role','user');
$query = $this->db->get('hr_user');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
	$this->load->view('/parts/pheadermeta');
	?>

</head>

<body class="fixed-nav sticky-footer" id="page-top">
    <!-- Navigation-->
    <?php
	$this->load->view('/doctor/navigation');
	?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">View profile</a>
                </li>
                <li class="breadcrumb-item active">User Profile</li>
            </ol>
            <div class="box_general">
                <div class="header_box">
                    <h2 class="d-inline-block">Patient List</h2>
                </div>
                <div class="list_general">
                    <?php
                foreach ($query->result() as $row){
                ?>
                    <ul>
                        <li>
                            <figure><img src="data:image/png;base64,<?php echo base64_encode($row->hru_avtar)?>" alt="Avatar" class="img-fluid rounded-circle mb-3" width="100"></figure>

                            <h4><?php echo $row->hru_name; ?></h4>
                            <p>Blood-Group: <b><?php echo $row->hru_bloodgroup; ?></b></p>

                            <p><a href="/doctor/viewuser/<?php echo $row->hru_ID; ?>" class="btn_1 gray"><i class="fa fa-fw fa-user"></i> View profile</a></p>
                        </li>

                    </ul>
                    <?php
                }
                ?>

                </div>
            </div>
            <!-- /box_general-->

            <!-- /pagination-->
        </div>
    </div>
    <footer class="sticky-footer">
        <div class="container">
            <div class="text-center">
                <small>Copyright © Health Register 2019</small>
            </div>
        </div>
    </footer>
    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <?php
	$this->load->view('/logout');
	?>
    <!-- Bootstrap core JavaScript-->
    <?php
	$this->load->view('/parts/pfootermeta');
	?>


</body>

</html>
