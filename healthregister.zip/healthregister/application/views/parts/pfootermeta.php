<script src="/panelassets/vendor/jquery/jquery.min.js"></script>
<script src="/panelassets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="/panelassets/vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Page level plugin JavaScript-->
<script src="/panelassets/vendor/chart.js/Chart.js"></script>
<script src="/panelassets/vendor/datatables/jquery.dataTables.js"></script>
<script src="/panelassets/vendor/datatables/dataTables.bootstrap4.js"></script>
<script src="/panelassets/vendor/jquery.selectbox-0.2.js"></script>
<script src="/panelassets/vendor/retina-replace.min.js"></script>
<script src="/panelassets/vendor/jquery.magnific-popup.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="/panelassets/js/admin.js"></script>
<!-- Custom scripts for this page-->
<script src="/panelassets/js/admin-charts.js"></script>
<script src="/panelassets/vendor/dropzone.min.js"></script>
<script src="/assets/js/typeahead.bundle.js"></script>
