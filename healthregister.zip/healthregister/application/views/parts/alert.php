<?php
if($this->session->flashdata('alert') != ''){
?>
<div class="alert alert-<?php echo $this->session->flashdata('alert') ?> fade show" role="alert">
    <span class="small"><?php echo $this->session->flashdata('message'); ?></span>
    <button type="button" class="close" aria-label="Close" data-dismiss="alert">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php
}
?>
