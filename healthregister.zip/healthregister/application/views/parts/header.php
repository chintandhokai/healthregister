<div id="preloader" class="Fixed">
    <div data-loader="circle-side"></div>
</div>
<!-- /Preload-->

<div id="page">
    <header class="header_sticky">
        <a href="#menu" class="btn_mobile">
            <div class="hamburger hamburger--spin" id="hamburger">
                <div class="hamburger-box">
                    <div class="hamburger-inner"></div>
                </div>
            </div>
        </a>
        <!-- /btn_mobile-->
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div id="logo_home">
                        <h1><a href="/assets/img/logo1.png" title="Health Register">Health Register</a></h1>
                    </div>
                </div>
                <div class="col-lg-9 col-6">
                    <nav id="menu" class="main-menu">
                        <ul>
                             <li>
                                <span><a href="/">Home</a></span>

                            </li>
                            <li>
                                <span><a href="/doctor/listview">Doctors</a></span>

                            </li>
                            <li>
                                <span><a href="/chemist/listview">Clinic</a></span>
                            </li>
                            <li>
                                <span><a href="/search">Blood Search</a></span>
                            </li>
                            <li>
                                <span><a href="/register">Register</a></span>
                            </li>
                            <li><span><a href="/login">Login</a></span></li>
                        </ul>
                    </nav>
                    <!-- /main-menu -->
                </div>
            </div>
        </div>
        <!-- /container -->
    </header>
    <!-- /header -->
