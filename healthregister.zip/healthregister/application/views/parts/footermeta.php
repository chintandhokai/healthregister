<!-- COMMON SCRIPTS -->
<script src="/assets/js/jquery-2.2.4.min.js"></script>
<script src="/assets/js/common_scripts.min.js"></script>
<script src="/assets/js/functions.js"></script>
<script src="/assets/js/typeahead.bundle.js"></script>
<script src="/assets/parsleyjs/parsley.min.js"></script>
