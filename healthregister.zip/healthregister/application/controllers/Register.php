<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function index()
	{
		$this->load->view('register');
	}
	public function doctor()
	{
		$this->load->view('registerdoctor');
	}
    public function doctorprocess()
	{
        $data = array(
            'hru_role'=>'doctor',
            'hru_email'=>$this->input->post('email_register'),
            'hru_name'=>$this->input->post('name_register'),
            'hru_specialization'=>$this->input->post('specialization'),
            'hru_city'=>$this->input->post('city_register'),
            'hru_address'=>$this->input->post('address_register'),
            'hru_mobile'=>$this->input->post('mobile_register'),
            'hru_office_mobile'=>$this->input->post('office_phone_register'),
            'hru_password'=>$this->input->post('password_register')
        );
        $query = $this->db->insert('hr_user',$data);
        if($query){
            $this->HR_model->noerr('<strong>Well done!</strong> Register Success.</span>');
            redirect('/login', 'refresh');
            die();
        }else{
            $this->HR_model->err('<strong>Ops !</strong> Look\'s like we got some error. <br> Please try again.');
            redirect('/login', 'refresh');
            die();
        }
        
	}
    public function user()
	{
		$this->load->view('registeruser');
	}
    public function userprocess()
	{
        $data = array(
            'hru_role'=>'user',
            'hru_email'=>$this->input->post('email_register'),
            'hru_name'=>$this->input->post('name_register'),
            'hru_specialization'=>$this->input->post('specialization'),
            'hru_city'=>$this->input->post('city_register'),
            'hru_address'=>$this->input->post('address_register'),
            'hru_mobile'=>$this->input->post('mobile_register'),
            'hru_office_mobile'=>$this->input->post('office_phone_register'),
            'hru_password'=>$this->input->post('password_register')
        );
        $query = $this->db->insert('hr_user',$data);
        if($query){
            $this->HR_model->noerr('<strong>Well done!</strong> Register Success.</span>');
            redirect('/login', 'refresh');
            die();
        }else{
            $this->HR_model->err('<strong>Ops !</strong> Look\'s like we got some error. <br> Please try again.');
            redirect('/login', 'refresh');
            die();
        }
	}
    public function chemist()
	{
		$this->load->view('registerchemist');
    }
    public function chemistprocess()
	{
		$data = array(
            'hru_role'=>'chemist',
            'hru_email'=>$this->input->post('email_register'),
            'hru_name'=>$this->input->post('name_register'),
            'hru_specialization'=>$this->input->post('specialization'),
            'hru_clinic'=>$this->input->post('clinic'),
            'hru_city'=>$this->input->post('city_register'),
            'hru_address'=>$this->input->post('address_register'),
            'hru_mobile'=>$this->input->post('mobile_register'),
            'hru_password'=>$this->input->post('password_register')
        );
        $query = $this->db->insert('hr_user',$data);
        if($query){
            $this->HR_model->noerr('<strong>Well done!</strong> Register Success.</span>');
            redirect('/login', 'refresh');
            die();
        }else{
            $this->HR_model->err('<strong>Ops !</strong> Look\'s like we got some error. <br> Please try again.');
            redirect('/login', 'refresh');
            die();
        }
	}
}
