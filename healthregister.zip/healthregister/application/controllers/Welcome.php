<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}
    public function logout()
    {
        $this->HR_model->noerr('<strong>Well done !</strong> Logged out Success.');
        $this->session->unset_userdata('email');
        redirect('/login/index','refresh');
        die();
    }
    private function email_exists($email)
    {
        $this->db->where('hru_email', $email);
        $query = $this->db->get('hr_user');
        if( $query->num_rows() > 0 ){ return TRUE; } else { return FALSE; }
    }
    function register_email_exists()
    {
        if (array_key_exists('email',$_POST)) {
            if ( $this->email_exists($this->input->post('email')) == TRUE ) {
                http_response_code(404);
            } else {
                http_response_code(200);
            }
        }
    }
}
?>
