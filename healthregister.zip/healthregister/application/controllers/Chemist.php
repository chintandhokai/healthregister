<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chemist extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
     public function index()
	{
		$this->load->view('/chemist/index');
	}
public function profile()
	{
		$this->session->set_flashdata('heading','Manage Profile');
		$this->load->view('/chemist/profile');
	}
     public function listview()
	{
		$this->load->view('clinic');
	}
    
public function profileedit()
    {
        if($_FILES['avtar']['name'] == ''){
            $data = array(
                'hru_name'=>$this->input->post('name'),
                'hru_specialization' => $this->input->post('specialization'),
                'hru_clinic'=>$this->input->post('clinic'),
                'hru_mobile' => $this->input->post('mobile'),
                'hru_bloodgroup'=>$this->input->post('bloodgroup'),
                'hru_gender' => $this->input->post('gender'),
                'hru_dob' => $this->input->post('dob'),
                'hru_city' => $this->input->post('city'),
                'hru_address' => $this->input->post('address'),
            );
        }
        else{
            $data = array(
                'hru_avtar' => file_get_contents($_FILES['avtar']['tmp_name']),
                'hru_name'=>$this->input->post('name'),
                'hru_specialization' => $this->input->post('specialization'),
                'hru_clinic'=>$this->input->post('clinic'),
                'hru_mobile' => $this->input->post('mobile'),
                'hru_bloodgroup'=>$this->input->post('bloodgroup'),
                'hru_gender' => $this->input->post('gender'),
                'hru_dob' => $this->input->post('dob'),
                'hru_city' => $this->input->post('city'),
                'hru_address' => $this->input->post('address'),
            );
        }
        $query1 = $this->db->where('hru_email',$this->session->userdata('email'));
        $query1 = $this->db->update('hr_user', $data);
        if($query1){
            $this->HR_model->noerr('<strong>Well done!</strong> Update Success.</span>');
            redirect('/chemist/profile', 'refresh');
            die();
        }else{
            $this->HR_model->err('<strong>Ops !</strong> Look\'s like we got some error. <br> Please try again.');
            redirect('/chemist/profile', 'refresh');
            die();
        }
    }
    public function adduser()
	{
		$this->load->view('/chemist/adduser');
	}
    public function adduserprocess()
	{
        $data = array(
            'hru_role'=>'user',
            'hru_avtar' => file_get_contents($_FILES['avtar']['tmp_name']),
            'hru_name'=>$this->input->post('name'),
            'hru_email'=>$this->input->post('email'),
            'hru_password'=>$this->input->post('password'),
            'hru_mobile'=>$this->input->post('mobile'),
            'hru_bloodgroup'=>$this->input->post('bloodgroup'),
            'hru_gender'=>$this->input->post('gender'),
            'hru_dob'=>$this->input->post('dob'),
             'hru_resume' => file_get_contents($_FILES['resume']['tmp_name']),
            'hru_city'=>$this->input->post('city'),
            'hru_address'=>$this->input->post('address')
        );
        $query = $this->db->insert('hr_user',$data);
        if($query){
            $this->HR_model->noerr('<strong>Well done!</strong> Add User Success.</span>');
            redirect('/chemist/adduser', 'refresh');
            die();
        }else{
            $this->HR_model->err('<strong>Ops !</strong> Look\'s like we got some error. <br> Please try again.');
            redirect('/login', 'refresh');
            die();
        }
	}
    public function userprofile()
	{
		$this->load->view('/chemist/userprofile');
	}
     public function viewuser($id){
        $data['id'] = $id;
        $this->load->view('/chemist/viewuser',$data);
    }
    public function userprofileedit($id)
    {
        if($_FILES['avtar']['name'] == '' && $_FILES['resume']['name'] == '') {
            $data = array(
               
                'hru_name'=>$this->input->post('name'),
              
                'hru_mobile' => $this->input->post('mobile'),
                'hru_bloodgroup'=>$this->input->post('bloodgroup'),
                'hru_gender' => $this->input->post('gender'),
                'hru_dob' => $this->input->post('dob'),     
                'hru_city' => $this->input->post('city'),
                'hru_address' => $this->input->post('address')
            );
        }
        if($_FILES['avtar']['name'] == ''){
            $data = array(
                'hru_name'=>$this->input->post('name'),
               
                'hru_mobile' => $this->input->post('mobile'),
                'hru_bloodgroup'=>$this->input->post('bloodgroup'),
                'hru_gender' => $this->input->post('gender'),
                'hru_dob' => $this->input->post('dob'),
                'hru_resume' => file_get_contents($_FILES['resume']['tmp_name']),
                'hru_city' => $this->input->post('city'),
                'hru_address' => $this->input->post('address')
            );
        }
            if($_FILES['resume']['name'] == ''){
            $data = array(
               'hru_avtar' => file_get_contents($_FILES['avtar']['tmp_name']),
                'hru_name'=>$this->input->post('name'),             
                'hru_mobile' => $this->input->post('mobile'),
                'hru_bloodgroup'=>$this->input->post('bloodgroup'),
                'hru_gender' => $this->input->post('gender'),
                'hru_dob' => $this->input->post('dob'),                
                'hru_city' => $this->input->post('city'),
                'hru_address' => $this->input->post('address')
            );
         
        }
        $query1 = $this->db->where('hru_ID',$id);
        $query1 = $this->db->update('hr_user', $data);
        if($query1){
            $this->HR_model->noerr('<strong>Well done!</strong> Update Success.</span>');
            redirect('/chemists/viewuser/'.$id, 'refresh');
            die();
        }else{
            $this->HR_model->err('<strong>Ops !</strong> Look\'s like we got some error. <br> Please try again.');
            redirect('/chemist/viewuser/'.$id, 'refresh');
            die();
        }
    }
}
?>
